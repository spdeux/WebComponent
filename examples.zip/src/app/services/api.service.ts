import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject, timer } from 'rxjs';
import { catchError, switchMap, retry } from 'rxjs/operators';
import { 
  ApiResponse, 
  DirectDepositSettings, 
  BankAccount, 
  TokenInfo 
} from '../interfaces/direct-deposit.interface';
import { EventEmissionService } from './event-emission.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = '/api/direct-deposit'; // This will be configurable
  private tokenSubject = new BehaviorSubject<TokenInfo | null>(null);
  private tokenCheckInterval: any;

  constructor(
    private http: HttpClient,
    private eventService: EventEmissionService
  ) {
    this.startTokenMonitoring();
  }

  /**
   * Set the API base URL (configurable for different domains)
   */
  setBaseUrl(url: string): void {
    this.baseUrl = url;
  }

  /**
   * Update the authentication token
   */
  updateToken(token: string, expiresIn?: number): void {
    const tokenInfo: TokenInfo = {
      token,
      expiresAt: expiresIn ? Date.now() + (expiresIn * 1000) : Date.now() + (3600 * 1000) // Default 1 hour
    };
    
    this.tokenSubject.next(tokenInfo);
    console.log('[DirectDeposit] Token updated', { expiresAt: new Date(tokenInfo.expiresAt) });
  }

  /**
   * Get current token
   */
  private getCurrentToken(): string | null {
    const tokenInfo = this.tokenSubject.value;
    if (!tokenInfo) return null;
    
    // Check if token is expired
    if (Date.now() >= tokenInfo.expiresAt) {
      this.handleTokenExpiration();
      return null;
    }
    
    return tokenInfo.token;
  }

  /**
   * Handle token expiration
   */
  private handleTokenExpiration(): void {
    console.log('[DirectDeposit] Token expired, requesting refresh');
    this.tokenSubject.next(null);
    this.eventService.emitTokenRefreshRequired('Token expired');
  }

  /**
   * Start monitoring token expiration
   */
  private startTokenMonitoring(): void {
    // Check token every 30 seconds
    this.tokenCheckInterval = timer(0, 30000).subscribe(() => {
      const tokenInfo = this.tokenSubject.value;
      if (tokenInfo) {
        const timeUntilExpiry = tokenInfo.expiresAt - Date.now();
        // Request refresh 5 minutes before expiration
        if (timeUntilExpiry > 0 && timeUntilExpiry < 300000) {
          this.eventService.emitTokenRefreshRequired('Token expiring soon');
        }
      }
    });
  }

  /**
   * Get HTTP headers with authorization
   */
  private getHeaders(): HttpHeaders {
    const token = this.getCurrentToken();
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    return headers;
  }

  /**
   * Handle HTTP errors
   */
  private handleError = (error: HttpErrorResponse) => {
    let errorMessage = 'An error occurred';

    if (error.status === 401) {
      this.handleTokenExpiration();
      errorMessage = 'Authentication failed';
    } else if (error.status === 403) {
      errorMessage = 'Access forbidden';
    } else if (error.status === 404) {
      errorMessage = 'Resource not found';
    } else if (error.status === 500) {
      errorMessage = 'Server error';
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    this.eventService.emitError(errorMessage, 'API Request');
    return throwError(() => new Error(errorMessage));
  };

  /**
   * Get direct deposit settings
   */
  getDirectDepositSettings(employeeId: string): Observable<ApiResponse<DirectDepositSettings>> {
    return this.http.get<ApiResponse<DirectDepositSettings>>(
      `${this.baseUrl}/settings/${employeeId}`,
      { headers: this.getHeaders() }
    ).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  /**
   * Update direct deposit settings
   */
  updateDirectDepositSettings(settings: DirectDepositSettings): Observable<ApiResponse<DirectDepositSettings>> {
    return this.http.put<ApiResponse<DirectDepositSettings>>(
      `${this.baseUrl}/settings`,
      settings,
      { headers: this.getHeaders() }
    ).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Add bank account
   */
  addBankAccount(account: BankAccount): Observable<ApiResponse<BankAccount>> {
    return this.http.post<ApiResponse<BankAccount>>(
      `${this.baseUrl}/accounts`,
      account,
      { headers: this.getHeaders() }
    ).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Remove bank account
   */
  removeBankAccount(accountId: string): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(
      `${this.baseUrl}/accounts/${accountId}`,
      { headers: this.getHeaders() }
    ).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Verify bank account
   */
  verifyBankAccount(accountId: string, verificationData: any): Observable<ApiResponse<BankAccount>> {
    return this.http.post<ApiResponse<BankAccount>>(
      `${this.baseUrl}/accounts/${accountId}/verify`,
      verificationData,
      { headers: this.getHeaders() }
    ).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Get bank information by routing number
   */
  getBankInfo(routingNumber: string): Observable<ApiResponse<{ bankName: string; isValid: boolean }>> {
    return this.http.get<ApiResponse<{ bankName: string; isValid: boolean }>>(
      `${this.baseUrl}/banks/lookup/${routingNumber}`,
      { headers: this.getHeaders() }
    ).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Cleanup resources
   */
  ngOnDestroy(): void {
    if (this.tokenCheckInterval) {
      this.tokenCheckInterval.unsubscribe();
    }
  }
} 