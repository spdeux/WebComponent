import { Injectable } from '@angular/core';
import { EventData, DepositEventType } from '../interfaces/direct-deposit.interface';

@Injectable({
  providedIn: 'root'
})
export class EventEmissionService {

  constructor() { }

  /**
   * Emit custom event to notify host application
   */
  emitEvent(type: DepositEventType, payload: any): void {
    const eventData: EventData = {
      type,
      payload,
      timestamp: Date.now(),
      source: 'direct-deposit-component'
    };

    // Create and dispatch custom event
    const customEvent = new CustomEvent(type, {
      detail: eventData,
      bubbles: true,
      cancelable: true
    });

    // Dispatch from document to ensure it reaches the host
    document.dispatchEvent(customEvent);

    // Also dispatch from window for broader compatibility
    window.dispatchEvent(customEvent);

    console.log(`[DirectDeposit] Event emitted: ${type}`, eventData);
  }

  /**
   * Emit state change event
   */
  emitStateChanged(newState: any): void {
    this.emitEvent(DepositEventType.STATE_CHANGED, {
      state: newState,
      timestamp: Date.now()
    });
  }

  /**
   * Emit token refresh required event
   */
  emitTokenRefreshRequired(reason: string = 'Token expired'): void {
    this.emitEvent(DepositEventType.TOKEN_REFRESH_REQUIRED, {
      reason,
      timestamp: Date.now(),
      requestId: this.generateRequestId()
    });
  }

  /**
   * Emit account added event
   */
  emitAccountAdded(account: any): void {
    this.emitEvent(DepositEventType.ACCOUNT_ADDED, {
      account,
      timestamp: Date.now()
    });
  }

  /**
   * Emit account removed event
   */
  emitAccountRemoved(accountId: string): void {
    this.emitEvent(DepositEventType.ACCOUNT_REMOVED, {
      accountId,
      timestamp: Date.now()
    });
  }

  /**
   * Emit settings updated event
   */
  emitSettingsUpdated(settings: any): void {
    this.emitEvent(DepositEventType.SETTINGS_UPDATED, {
      settings,
      timestamp: Date.now()
    });
  }

  /**
   * Emit verification completed event
   */
  emitVerificationCompleted(accountId: string, success: boolean): void {
    this.emitEvent(DepositEventType.VERIFICATION_COMPLETED, {
      accountId,
      success,
      timestamp: Date.now()
    });
  }

  /**
   * Emit error occurred event
   */
  emitError(error: string | Error, context?: string): void {
    const errorMessage = error instanceof Error ? error.message : error;
    this.emitEvent(DepositEventType.ERROR_OCCURRED, {
      error: errorMessage,
      context,
      timestamp: Date.now()
    });
  }

  /**
   * Generate unique request ID
   */
  private generateRequestId(): string {
    return `dd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
} 