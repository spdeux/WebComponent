export interface BankAccount {
  id?: string;
  accountType: 'checking' | 'savings';
  routingNumber: string;
  accountNumber: string;
  bankName: string;
  isVerified?: boolean;
}

export interface DirectDepositSettings {
  id?: string;
  employeeId: string;
  accounts: BankAccount[];
  totalAllocationPercentage: number;
  isActive: boolean;
}

export interface AllocationRule {
  accountId: string;
  percentage: number;
  fixedAmount?: number;
  priority: number;
}

export interface DepositState {
  currentScreen: string;
  isLoading: boolean;
  errors: string[];
  settings?: DirectDepositSettings;
  pendingChanges: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: string[];
}

export interface TokenInfo {
  token: string;
  expiresAt: number;
  refreshToken?: string;
}

export interface EventData {
  type: string;
  payload: any;
  timestamp: number;
  source: 'direct-deposit-component';
}

export enum DepositEventType {
  STATE_CHANGED = 'depositStateChanged',
  TOKEN_REFRESH_REQUIRED = 'tokenRefreshRequired',
  ACCOUNT_ADDED = 'accountAdded',
  ACCOUNT_REMOVED = 'accountRemoved',
  SETTINGS_UPDATED = 'settingsUpdated',
  VERIFICATION_COMPLETED = 'verificationCompleted',
  ERROR_OCCURRED = 'errorOccurred'
} 