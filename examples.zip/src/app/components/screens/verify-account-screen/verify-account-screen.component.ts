import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DirectDepositSettings } from '../../../interfaces/direct-deposit.interface';

@Component({
  selector: 'dd-verify-account-screen',
  template: `
    <div class="card">
      <h3>Verify Account</h3>
      <p>This screen would contain micro-deposit verification or instant verification.</p>
      <div class="actions">
        <button class="btn btn-secondary" (click)="onCancel()">Cancel</button>
        <button class="btn btn-primary" (click)="onVerify()">Verify Account</button>
      </div>
    </div>
  `,
  styles: [`
    .actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      margin-top: 24px;
    }
  `]
})
export class VerifyAccountScreenComponent {
  @Input() settings: DirectDepositSettings | null = null;
  @Output() accountVerified = new EventEmitter<{accountId: string, verificationData: any}>();
  @Output() cancel = new EventEmitter<void>();

  onVerify(): void {
    const accountId = this.settings?.accounts?.[0]?.id || 'default-id';
    this.accountVerified.emit({
      accountId,
      verificationData: { verified: true }
    });
  }

  onCancel(): void {
    this.cancel.emit();
  }
} 