import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DirectDepositSettings } from '../../../interfaces/direct-deposit.interface';

@Component({
  selector: 'dd-confirmation-screen',
  template: `
    <div class="card">
      <h3>Confirmation</h3>
      <div class="success-message">
        <div class="success-icon">✓</div>
        <h4>Direct Deposit Setup Complete!</h4>
        <p>Your changes have been saved successfully.</p>
      </div>
      <div class="actions">
        <button class="btn btn-primary" (click)="onDone()">Done</button>
      </div>
    </div>
  `,
  styles: [`
    .success-message {
      text-align: center;
      padding: 40px 20px;
    }
    .success-icon {
      font-size: 48px;
      color: var(--success-color);
      margin-bottom: 16px;
    }
    .actions {
      display: flex;
      justify-content: center;
      margin-top: 24px;
    }
  `]
})
export class ConfirmationScreenComponent {
  @Input() settings: DirectDepositSettings | null = null;
  @Output() done = new EventEmitter<void>();

  onDone(): void {
    this.done.emit();
  }
} 