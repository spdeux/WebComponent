import { Component, Output, EventEmitter } from '@angular/core';
import { BankAccount } from '../../../interfaces/direct-deposit.interface';

@Component({
  selector: 'dd-add-account-screen',
  template: `
    <div class="card">
      <h3>Add Bank Account</h3>
      <p>This screen would contain a form to add a new bank account.</p>
      <div class="actions">
        <button class="btn btn-secondary" (click)="onCancel()">Cancel</button>
        <button class="btn btn-primary" (click)="onSubmit()">Add Account</button>
      </div>
    </div>
  `,
  styles: [`
    .actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      margin-top: 24px;
    }
  `]
})
export class AddAccountScreenComponent {
  @Output() accountAdded = new EventEmitter<BankAccount>();
  @Output() cancel = new EventEmitter<void>();

  onSubmit(): void {
    // Mock account data
    const mockAccount: BankAccount = {
      id: 'acc-' + Date.now(),
      accountType: 'checking',
      routingNumber: '123456789',
      accountNumber: '987654321',
      bankName: 'Sample Bank',
      isVerified: false
    };
    this.accountAdded.emit(mockAccount);
  }

  onCancel(): void {
    this.cancel.emit();
  }
} 