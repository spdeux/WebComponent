import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DirectDepositSettings, BankAccount, DepositState } from '../../../interfaces/direct-deposit.interface';

@Component({
  selector: 'dd-overview-screen',
  templateUrl: './overview-screen.component.html',
  styleUrls: ['./overview-screen.component.scss']
})
export class OverviewScreenComponent {
  @Input() settings: DirectDepositSettings | null = null;
  @Input() state: DepositState | null = null;

  @Output() addAccount = new EventEmitter<void>();
  @Output() editAllocation = new EventEmitter<void>();
  @Output() verifyAccount = new EventEmitter<string>();
  @Output() removeAccount = new EventEmitter<string>();

  constructor() { }

  onAddAccount(): void {
    this.addAccount.emit();
  }

  onEditAllocation(): void {
    this.editAllocation.emit();
  }

  onVerifyAccount(accountId: string): void {
    this.verifyAccount.emit(accountId);
  }

  onRemoveAccount(accountId: string): void {
    if (confirm('Are you sure you want to remove this account?')) {
      this.removeAccount.emit(accountId);
    }
  }

  getAccountTypeLabel(type: string): string {
    return type === 'checking' ? 'Checking' : 'Savings';
  }

  maskAccountNumber(accountNumber: string): string {
    if (!accountNumber || accountNumber.length < 4) return '****';
    return '*'.repeat(accountNumber.length - 4) + accountNumber.slice(-4);
  }

  hasAccounts(): boolean {
    return this.settings?.accounts && this.settings.accounts.length > 0;
  }

  getTotalAllocation(): number {
    return this.settings?.totalAllocationPercentage || 0;
  }

  isSetupComplete(): boolean {
    return this.hasAccounts() && this.getTotalAllocation() === 100;
  }
} 