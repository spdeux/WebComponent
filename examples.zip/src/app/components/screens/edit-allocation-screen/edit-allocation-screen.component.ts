import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DirectDepositSettings } from '../../../interfaces/direct-deposit.interface';

@Component({
  selector: 'dd-edit-allocation-screen',
  template: `
    <div class="card">
      <h3>Edit Allocation</h3>
      <p>This screen would contain controls to edit percentage allocations.</p>
      <div class="actions">
        <button class="btn btn-secondary" (click)="onCancel()">Cancel</button>
        <button class="btn btn-primary" (click)="onUpdate()">Update Allocation</button>
      </div>
    </div>
  `,
  styles: [`
    .actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      margin-top: 24px;
    }
  `]
})
export class EditAllocationScreenComponent {
  @Input() settings: DirectDepositSettings | null = null;
  @Output() allocationUpdated = new EventEmitter<DirectDepositSettings>();
  @Output() cancel = new EventEmitter<void>();

  onUpdate(): void {
    if (this.settings) {
      const updatedSettings = { ...this.settings, totalAllocationPercentage: 100 };
      this.allocationUpdated.emit(updatedSettings);
    }
  }

  onCancel(): void {
    this.cancel.emit();
  }
} 