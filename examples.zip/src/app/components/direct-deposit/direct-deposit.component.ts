import { Component, OnInit, OnDestroy, Input, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { 
  DirectDepositSettings, 
  BankAccount, 
  DepositState 
} from '../../interfaces/direct-deposit.interface';
import { ApiService } from '../../services/api.service';
import { EventEmissionService } from '../../services/event-emission.service';

@Component({
  selector: 'dd-direct-deposit',
  templateUrl: './direct-deposit.component.html',
  styleUrls: ['./direct-deposit.component.scss'],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class DirectDepositComponent implements OnInit, OnDestroy {
  @Input() employeeId: string = '';
  @Input() apiBaseUrl: string = '/api/direct-deposit';
  @Input() authToken: string = '';

  currentScreen: string = 'overview';
  screens = {
    OVERVIEW: 'overview',
    ADD_ACCOUNT: 'add-account',
    EDIT_ALLOCATION: 'edit-allocation',
    VERIFY_ACCOUNT: 'verify-account',
    CONFIRMATION: 'confirmation'
  };

  state: DepositState = {
    currentScreen: 'overview',
    isLoading: false,
    errors: [],
    pendingChanges: false
  };

  settings: DirectDepositSettings | null = null;
  private destroy$ = new Subject<void>();

  constructor(
    private apiService: ApiService,
    private eventService: EventEmissionService
  ) {}

  ngOnInit(): void {
    this.initializeComponent();
    this.loadDirectDepositSettings();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Initialize component with provided inputs
   */
  private initializeComponent(): void {
    if (this.apiBaseUrl) {
      this.apiService.setBaseUrl(this.apiBaseUrl);
    }

    if (this.authToken) {
      this.apiService.updateToken(this.authToken);
    }

    this.updateState({ currentScreen: this.currentScreen });
  }

  /**
   * Update component state and emit events
   */
  private updateState(newState: Partial<DepositState>): void {
    this.state = { ...this.state, ...newState };
    this.eventService.emitStateChanged(this.state);
  }

  /**
   * Load direct deposit settings from API
   */
  private loadDirectDepositSettings(): void {
    if (!this.employeeId) {
      this.updateState({ 
        errors: ['Employee ID is required'], 
        isLoading: false 
      });
      return;
    }

    this.updateState({ isLoading: true, errors: [] });

    this.apiService.getDirectDepositSettings(this.employeeId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.settings = response.data;
            this.updateState({ 
              settings: response.data, 
              isLoading: false 
            });
          } else {
            this.updateState({ 
              errors: response.errors || ['Failed to load settings'], 
              isLoading: false 
            });
          }
        },
        error: (error) => {
          this.updateState({ 
            errors: [error.message || 'Failed to load settings'], 
            isLoading: false 
          });
        }
      });
  }

  /**
   * Navigate to a specific screen
   */
  navigateToScreen(screen: string): void {
    this.currentScreen = screen;
    this.updateState({ currentScreen: screen });
  }

  /**
   * Add a new bank account
   */
  onAddAccount(account: BankAccount): void {
    this.updateState({ isLoading: true, errors: [] });

    this.apiService.addBankAccount(account)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.eventService.emitAccountAdded(response.data);
            this.loadDirectDepositSettings(); // Refresh settings
            this.navigateToScreen(this.screens.OVERVIEW);
          } else {
            this.updateState({ 
              errors: response.errors || ['Failed to add account'], 
              isLoading: false 
            });
          }
        },
        error: (error) => {
          this.updateState({ 
            errors: [error.message || 'Failed to add account'], 
            isLoading: false 
          });
        }
      });
  }

  /**
   * Remove a bank account
   */
  onRemoveAccount(accountId: string): void {
    this.updateState({ isLoading: true, errors: [] });

    this.apiService.removeBankAccount(accountId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (response.success) {
            this.eventService.emitAccountRemoved(accountId);
            this.loadDirectDepositSettings(); // Refresh settings
          } else {
            this.updateState({ 
              errors: response.errors || ['Failed to remove account'], 
              isLoading: false 
            });
          }
        },
        error: (error) => {
          this.updateState({ 
            errors: [error.message || 'Failed to remove account'], 
            isLoading: false 
          });
        }
      });
  }

  /**
   * Update allocation settings
   */
  onUpdateAllocation(settings: DirectDepositSettings): void {
    this.updateState({ isLoading: true, errors: [] });

    this.apiService.updateDirectDepositSettings(settings)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.settings = response.data;
            this.eventService.emitSettingsUpdated(response.data);
            this.updateState({ 
              settings: response.data, 
              isLoading: false,
              pendingChanges: false 
            });
            this.navigateToScreen(this.screens.CONFIRMATION);
          } else {
            this.updateState({ 
              errors: response.errors || ['Failed to update settings'], 
              isLoading: false 
            });
          }
        },
        error: (error) => {
          this.updateState({ 
            errors: [error.message || 'Failed to update settings'], 
            isLoading: false 
          });
        }
      });
  }

  /**
   * Handle account verification
   */
  onVerifyAccount(accountId: string, verificationData: any): void {
    this.updateState({ isLoading: true, errors: [] });

    this.apiService.verifyBankAccount(accountId, verificationData)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (response.success && response.data) {
            this.eventService.emitVerificationCompleted(accountId, true);
            this.loadDirectDepositSettings(); // Refresh settings
            this.navigateToScreen(this.screens.OVERVIEW);
          } else {
            this.eventService.emitVerificationCompleted(accountId, false);
            this.updateState({ 
              errors: response.errors || ['Verification failed'], 
              isLoading: false 
            });
          }
        },
        error: (error) => {
          this.eventService.emitVerificationCompleted(accountId, false);
          this.updateState({ 
            errors: [error.message || 'Verification failed'], 
            isLoading: false 
          });
        }
      });
  }

  /**
   * Public method to update token (called by host application)
   */
  updateToken(token: string, expiresIn?: number): void {
    this.authToken = token;
    this.apiService.updateToken(token, expiresIn);
  }

  /**
   * Get current step number for progress indicator
   */
  getCurrentStep(): number {
    const steps = Object.values(this.screens);
    return steps.indexOf(this.currentScreen) + 1;
  }

  /**
   * Get total number of steps
   */
  getTotalSteps(): number {
    return Object.keys(this.screens).length;
  }

  /**
   * Check if current screen is the specified screen
   */
  isCurrentScreen(screen: string): boolean {
    return this.currentScreen === screen;
  }
} 